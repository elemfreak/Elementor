<?php

/**
 * Elementor widget class that add widget essential things
 * 
 * @since 1.0.0
 */
class Elementor_Custom_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 * 
	 * @since 1.0.0
	 * @access public
	 * @return string widget name.
	 */
	public function get_name() {
		return 'finegap_widget';
	}

	/**
	 * Get widget title
	 * 
	 * @since 1.0.0
	 * @access public
	 * @return string widget title.
	 */
	public function get_title() {
		return esc_html__( 'Finegap widget', 'custom-elementor-widget' );
	}

	/**
	 * Get widget icon
	 * 
	 * @since 1.0.0
	 * @access public
	 * @return string widget icon.
	 */
	public function get_icon() {
		return 'eicon-code';
	}

	/**
	 * Get widget help url
	 * 
	 * @since 1.0.0
	 * @access public
	 * @return string widget URL.
	 */
	public function get_custom_help_url() {
		return "https://finegap.com";
	}

	/**
	 * Get widget keywords for SEO
	 * 
	 * @since 1.0.0
	 * @access public
	 * @return array widget keywords.
	 */
	public function get_keywords() {
		return [ 'fine', 'gap', 'noman' ];
	}

	/**
	 * Register widget card controls
	 * 
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		
		// Content Tab Start
		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__( 'Finegap', 'custom-elementor-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Finegap Title', 'custom-elementor-widget' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Hello world', 'custom-elementor-widget' ),
			]
		);

		$this->end_controls_section();
		// Content Tab End


		// Style Tab Start
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Style finegap', 'custom-elementor-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'custom-elementor-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hello-world' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		// Style Tab End
	}

	/**
	 * Render widget out on frontend
	 * 
	 * @since 1.0.0
	 * @access protected
	 * @return 
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<p class="hello-world">
			<?php echo $settings['title']; ?>
		</p>

		<?php
	}

}

