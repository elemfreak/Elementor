<?php

/**
 * Plugin Name: Custom Elementor Widget 
 * Description: This plugin use to make custom elementor widget
 * Version: 1.0.0
 * Author: Finegap
 * Author URI: https://finegap.com
 * Text Domain: custom-elementor-widget
 */

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * Include widget and register widget class
 * 
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager 
 * @return void
 */
function register_finegap_widget( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/custom-widget.php' );

	$widgets_manager->register( new \Elementor_Custom_Widget() );

}
add_action( 'elementor/widgets/register', 'register_finegap_widget' );